package com.estiven.calculadora.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val Grey500 = Color(0xFF78909c)
// color blue
val Indigo300 = Color(0xFF9fa8da)
val Indigo500 = Color(0xFF5c6bc0)
val Indigo900 = Color(0xFF000051)