package com.estiven.calculadora.ui.views

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.estiven.calculadora.R
import com.estiven.calculadora.ui.theme.CalculadoraTheme
import com.estiven.calculadora.ui.viewmodel.MainActivityViewModel

class MainActivity : ComponentActivity() {

    private var textNumber: MutableState<String>? = null
    private var textResult: MutableState<String>? = null
    private lateinit var mainActivityViewModel: MainActivityViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            mainActivityViewModel = viewModel()
            CalculadoraTheme {
                AppBar()
                Column {
                    ResultScreen()
                    KeyBoard()
                }
                Test()
            }
        }
    }

    @Composable
    private fun Test() {
        ResultView()
    }
    
    @Composable
    fun ResultView(){
        Box(contentAlignment = Alignment.TopEnd) {

        }
    }


    @Composable
    fun AppBar() {
        val state = remember { mutableStateOf(false) }
        TopAppBar(
            title = {},
            navigationIcon = {
                Switch(
                    checked = state.value,
                    onCheckedChange = { value ->
                        state.value = value
                        changeTheme(value)
                    },
                    modifier = Modifier.padding(10.dp)
                )
            },
            backgroundColor = MaterialTheme.colors.secondary
        )
    }

    private fun changeTheme(checked: Boolean) {
        //
    }

    @Composable
    fun ResultScreen() {
        textNumber = remember { mutableStateOf("") }
        textResult = remember { mutableStateOf("") }
        Box(
            modifier = Modifier
                .background(MaterialTheme.colors.secondary)
                .fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(20.dp)
            ) {
                Text(
                    text = textNumber!!.value,
                    color = MaterialTheme.colors.onSecondary,
                    fontSize = 22.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
                Text(
                    text = textResult!!.value,
                    color = MaterialTheme.colors.onSecondary,
                    fontSize = 60.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
            }
        }
    }

    @Composable
    //fun KeyBoard(viewModel: MainActivityViewModel = viewModel()) {
    fun KeyBoard() {
        //ObserverViewModel()
        Box(
            modifier = Modifier
                .background(MaterialTheme.colors.background)
                .fillMaxWidth(),
        ) {
            Row {
                Column(modifier = Modifier.weight(4F)) {
                    Row {
                        ButtonNumber(number = "7") { textNumber!!.value = "${textNumber!!.value}7" }
                        ButtonNumber(number = "8") { textNumber!!.value = "${textNumber!!.value}8" }
                        ButtonNumber(number = "9") { textNumber!!.value = "${textNumber!!.value}9" }
                    }
                    Row {
                        ButtonNumber(number = "4") { textNumber!!.value = "${textNumber!!.value}4" }
                        ButtonNumber(number = "5") { textNumber!!.value = "${textNumber!!.value}5" }
                        ButtonNumber(number = "6") { textNumber!!.value = "${textNumber!!.value}6" }
                    }
                    Row {
                        ButtonNumber(number = "1") { textNumber!!.value = "${textNumber!!.value}1" }
                        ButtonNumber(number = "2") { textNumber!!.value = "${textNumber!!.value}2" }
                        ButtonNumber(number = "3") { textNumber!!.value = "${textNumber!!.value}3" }
                    }
                    Row {
                        ButtonNumber(number = "0") { textNumber!!.value = "${textNumber!!.value}0" }
                        ButtonNumber(number = ",") { textNumber!!.value = "${textNumber!!.value}." }
                        ButtonNumber(number = "=") {
                            //viewModel.showResult(textNumber?.value)
                        }
                    }
                }

                Column(modifier = Modifier.weight(1F)) {
                    ButtonOperations(icon = R.drawable.ic_baseline_backspace_24) {
                        textNumber?.value = ""
                        textResult?.value = ""
                    }
                    ButtonOperations(icon = R.drawable.ic_dividir) {
                        textNumber!!.value = "${textNumber!!.value}/"
                    }
                    ButtonOperations(icon = R.drawable.ic_baseline_close_24) {
                        textNumber!!.value = "${textNumber!!.value}*"
                    }
                    ButtonOperations(icon = R.drawable.ic_baseline_horizontal_rule_24) {
                        textNumber!!.value = "${textNumber!!.value}-"
                    }
                    ButtonOperations(icon = R.drawable.ic_baseline_add_24) {
                        textNumber!!.value = "${textNumber!!.value}+"
                    }
                }
            }
        }
    }

    @Composable
    private fun ObserverViewModel(viewModel: MainActivityViewModel = viewModel()) {
        // recuperamos los valores a traves del viewmodel
        val result by viewModel.resultText.observeAsState()
        val message by viewModel.message.observeAsState()
        // validamos que sean diferentes de nulo
        result.let { value ->
            if (value != null) {
                textResult?.value = value
            }
        }
        message.let { msg ->
            if (msg != null) {
                //
            }
        }
    }

    @Preview
    @Composable
    fun PreviewResult() {
        Column {
            //AppBar()
            //ResultScreen()
            //KeyBoard()
            Test()
        }
    }

    @Composable
    fun ButtonNumber(number: String, onClick: () -> Unit) {
        Button(
            onClick = onClick,
            modifier = Modifier
                .width(100.dp)
                .height(100.dp)
                .shadow(0.dp),
            colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.background),
            elevation = ButtonDefaults.elevation(0.dp),
        ) {
            Text(
                text = number,
                color = MaterialTheme.colors.onPrimary,
                fontSize = 40.sp
            )
        }
    }

    @Composable
    fun ButtonOperations(icon: Int, onClick: () -> Unit) {
        Button(
            onClick = onClick,
            modifier = Modifier
                .width(80.dp)
                .height(80.dp),
            colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.background),
            elevation = ButtonDefaults.elevation(0.dp)
        ) {
            Icon(
                painter = painterResource(id = icon),
                contentDescription = null,
                modifier = Modifier.size(38.dp),
                tint = MaterialTheme.colors.primaryVariant
            )
        }
    }
}