package com.estiven.calculadora.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import net.objecthunter.exp4j.ExpressionBuilder
import java.lang.ArithmeticException
import java.lang.IllegalArgumentException

class MainActivityViewModel : ViewModel() {

    private val _textResult = MutableLiveData<String>()
    private val _message = MutableLiveData<String>()
    val resultText: LiveData<String>
        get() = _textResult
    val message: LiveData<String>
        get() = _message

    fun showResult(value: String?) {
        // construir la expresion a evaluar
        val expression = ExpressionBuilder(value).build()
        if (!value.isNullOrEmpty()) {
            try {
                // evaluar la expresion
                val result = expression.evaluate()
                _textResult.value = result.toString()
            } catch (arithmeticException: ArithmeticException) {
                _message.value = arithmeticException.message
            } catch (illegalArgumentException: IllegalArgumentException) {
                _message.value = illegalArgumentException.message
            }
        } else {
            _message.value = "No hay ningun valor por evaluar"
        }
    }
}